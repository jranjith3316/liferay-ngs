import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import LiferayParams from '../../types/LiferayParams'

declare const Liferay: any;

@Injectable({
  providedIn: 'root'
})
export class LobService {

  params: LiferayParams;

  constructor(private http: HttpClient) { }

  getStates(catId: string): Observable<any> {
      return this.http.get(Liferay.ThemeDisplay.getPathContext() + '/o/headless-admin-taxonomy/v1.0/taxonomy-categories/' 
      + catId + '/taxonomy-categories?pageSize=100&sort=name');
  }

  setParams(params: any) {
    this.params = params;
  }

  getParams() {
    return this.params;
  }
}