import { Component} from '@angular/core';
import { LobService } from '../services/lobService';
import { LOB } from '../interfaces/lob';
import LiferayParams from '../../types/LiferayParams';
declare const Liferay: any;

@Component({
    selector: 'select-app',
	templateUrl: 
		Liferay.ThemeDisplay.getPathContext() + 
		'/o/lob-select/app/selector.component.html'
})
export class SelectorComponent {
	params: LiferayParams;
    state: string;
    lob: string;
    selectedState: number;
    selectedLob: number;
    splitLobs: any = [];
    lobObjects: LOB[] = [];
    currentLob: LOB = {
        name: '',
        categoryID: '',
        categories: []
    }

	constructor(private lobService: LobService) {}

    ngOnInit(): void {

        this.params = this.lobService.getParams();
        this.splitSections();
        this.getStates(0);
        this.selectedLob = 0;
    }

    splitSections() {

        this.splitLobs = this.params.configuration.system.lobs.split(",");

        for (var i = 0; i < this.splitLobs.length; i++) {

            var newSplit = [];
            newSplit = this.splitLobs[i].split(":");
            var myLob: LOB = {
                name: newSplit[0],
                categoryID: newSplit[1],
                categories: []
            }
            this.lobObjects.push(myLob);
        }
    }

    getStates(lob: number) {

        this.lobService.getStates(this.lobObjects[lob].categoryID).subscribe(states => {
            this.lobObjects[lob].categories.push(states.items);
            this.currentLob = this.lobObjects[lob];
            this.selectedState = 0;
            if (!this.lob && !this.state) {
                this.lob = this.currentLob.name;
                this.state = this.currentLob.categories[0][0].name;
            }
        })
    }

    cancelClose() {
        event.stopPropagation();
    }

    confirmChoice() {
        this.lob = this.currentLob.name;
        this.state = this.currentLob.categories[0][this.selectedState].name;
    }
}