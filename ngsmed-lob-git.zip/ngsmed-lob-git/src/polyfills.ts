// Import needed polyfills for the application
import 'core-js/es7/reflect';
import 'zone.js/dist/zone';
