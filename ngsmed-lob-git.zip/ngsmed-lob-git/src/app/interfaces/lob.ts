export interface LOB {
    name: string;
    categoryID: string;
    categories: any [];
    lobFilterCookie: string;
}