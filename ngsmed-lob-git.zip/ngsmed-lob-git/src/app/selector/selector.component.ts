import { Component, ViewChild } from '@angular/core';
import { LobService } from '../services/lobService';
import { LOB } from '../interfaces/lob';
import LiferayParams from '../../types/LiferayParams';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import * as Cookies from 'js-cookie';

declare const Liferay: any;

@Component({
    selector: 'select-app',
	templateUrl: 
		Liferay.ThemeDisplay.getPathContext() + 
		'/o/lob-select/app/selector.component.html'
})
export class SelectorComponent {
	params: LiferayParams;
    state: string;
    lob: string;
    selectedState: string;
    selectedLob: number;
    splitLobs: any = [];
    lobObjects: LOB[] = [];
    currentLob: LOB = {
        name: '',
        categoryID: '',
        categories: [],
        lobFilterCookie: ''
    }
    lobCookie: string;
    regionCookie: string;
    @ViewChild('content', { static: true }) private content: any;

    constructor(private lobService: LobService, private modalService: NgbModal) {}
    
    open(content: any) {
      this.modalService.open(content, {ariaLabelledBy: 'Pop-up to select your lob and region.', backdrop: 'static', keyboard: false});
    }

    ngOnInit(): void {

        this.lobCookie = Cookies.get('lob');
        this.regionCookie = Cookies.get('region');
        this.params = this.lobService.getParams();
        this.splitSections();

        if (this.lobCookie && this.regionCookie) {
            var currentIndex: number = this.lobObjects.findIndex(index => index.lobFilterCookie == this.lobCookie);
            this.lob = this.lobObjects.find(item => item.lobFilterCookie == this.lobCookie).name;
            this.lobService.getStates(this.lobObjects[currentIndex].categoryID).subscribe(states => {
                this.lobObjects[currentIndex].categories.push(states.items);
                this.currentLob = this.lobObjects[currentIndex];
                this.selectedLob = currentIndex;
            })
            this.state = this.regionCookie;
            this.selectedState = this.regionCookie;
        } else {
            this.open(this.content);
            this.getStates(0);
            this.selectedLob = 0;
        }
    }

    splitSections() {

        this.splitLobs = this.params.configuration.system.lobs.split(",");

        for (var i = 0; i < this.splitLobs.length; i++) {

            var newSplit = [];
            newSplit = this.splitLobs[i].split(":");
            var myLob: LOB = {
                name: newSplit[0],
                categoryID: newSplit[1],
                categories: [],
                lobFilterCookie: newSplit[2]
            }
            this.lobObjects.push(myLob);
        }
    }

    getStates(lob: number) {

        this.lobService.getStates(this.lobObjects[lob].categoryID).subscribe(states => {
            this.lobObjects[lob].categories.push(states.items);
            this.currentLob = this.lobObjects[lob];
            this.selectedState = this.currentLob.categories[0][0].name;
            if (!this.lob && !this.state) {
                this.lob = this.currentLob.name;
                this.state = this.currentLob.categories[0][0].name;
            }
        })
    }

    cancelClose() {
        event.stopPropagation();
    }

    confirmChoice() {
        Cookies.set('lob', this.currentLob.lobFilterCookie);
        Cookies.set('region', this.selectedState);
        location.reload();
    }
}