import { Component } from '@angular/core';
import { LobService } from './services/lobService';

import LiferayParams from '../types/LiferayParams';

declare const Liferay: any;

@Component({
	templateUrl: 
		Liferay.ThemeDisplay.getPathContext() + 
		'/o/lob-select/app/app.component.html'
})
export class AppComponent {
	params: LiferayParams;

	constructor(private lobService: LobService) {}

	ngOnInit(): void {

		this.lobService.setParams(this.params);
	}
}