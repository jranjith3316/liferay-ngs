/**
 * © 2017 Liferay, Inc. <https://liferay.com>
 *
 * SPDX-License-Identifier: MIT
 */

"use strict";

var gulp = require("gulp");
var liferayThemeTasks = require("liferay-theme-tasks");

liferayThemeTasks.registerTasks({
  gulp,
  hookFn: function(gulp) {
    gulp.hook("before:build:base", function(done) {
      gulp
        .src("./node_modules/js-cookie/src/js.cookie.js")
        .pipe(gulp.dest("src/js/"));
      done();
    });
  }
});
