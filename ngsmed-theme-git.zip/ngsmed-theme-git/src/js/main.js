function initializeLOBs(ngsLoc, ngsRegion) {
  let currentURLQueryParam = new URLSearchParams(window.location.search);
  let queryParamLOB = currentURLQueryParam.get('lob');
  let queryParamRegion = currentURLQueryParam.get('region');
  setLOB(queryParamLOB);
  setRegion(queryParamRegion);
}

function setLOB(lob) {
  if (lob && lob != "") {
    Cookies.set('lob', lob);
  }
}

function getLOB() {
  return Cookies.get('lob');
}

function setRegion(region) {
  if (region && region != "") {
    Cookies.set('region', region);
  }
}

function getRegion() {
  return Cookies.get('region');
}

function closeNav() {
  $("#navigationCollapse").removeClass("show");
}

initializeLOBs();